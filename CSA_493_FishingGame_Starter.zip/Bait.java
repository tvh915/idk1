/*
 * Activity 4.9.3
 */
public class Bait extends LakeObject
{

}