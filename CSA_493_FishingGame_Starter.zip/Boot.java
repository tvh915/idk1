/*
 * Activity 4.9.3
 */
public class Boot extends LakeObject
{

}
